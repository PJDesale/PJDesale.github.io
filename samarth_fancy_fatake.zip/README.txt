# समर्थ फॅन्सी फटाके — Website

A responsive Marathi informational website with click-to-call and WhatsApp inquiry links.

## Files
- `index.html` — page content
- `style.css` — responsive design and styling
- `script.js` — WhatsApp links and mobile menu

## Run on Windows
1. Download and extract `samarth_fancy_fatake_website.zip`.
2. Open the extracted folder.
3. Double-click `index.html` to preview in Chrome or Edge.
4. To edit the website, open the folder in Visual Studio Code.

No Python, Node.js, database, or paid API is required. Internet is needed for the optional Google Fonts and Google Maps link.

## Update WhatsApp number
Open `script.js` and change `WHATSAPP_NUMBER` to the shop's number in international format, without `+`, spaces, or dashes. Current value: `918788668120`.

## Update phone or address
Search in `index.html` for `8788668120`, `राजस्थान हॉटेलच्या बाजूला, झोडगे`, or `जगदीश देसले` and edit as needed.

## Publish online
You can host these static files on a static website host. Upload the contents of this folder, keeping `index.html`, `style.css`, and `script.js` together. Check that the WhatsApp and phone links work after publishing.

## Important
This website is informational; it does not take online payments or guarantee inventory. Confirm product availability, pricing, and applicable local fireworks rules with the shop before publishing claims.
